# UR_Label_Detection > 2025-04-19 5:47pm
https://universe.roboflow.com/objectdetection-50iqq/ur_label_detection

Provided by a Roboflow user
License: CC BY 4.0

